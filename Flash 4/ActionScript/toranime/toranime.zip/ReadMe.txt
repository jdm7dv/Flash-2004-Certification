All Training Version are freeware !
So use it in your own productions or 
on you website.

Signed: Madania Netware - 1999
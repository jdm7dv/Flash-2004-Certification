       Branden Hall 
       -=presents=-
     Flash 4 Trig Lib
-----------------------------

To use simply drop the M-trig
MC to your movie and name it.
(the rest of the doc assumes 
you named it trig.

Then you simply have to set the
variable /trig:angle and call 
either /trig:cos or /trig:sin
after the call, either the 
variable /trig:cos or /trig:sin
is set to the correct value.

This library is free to use, 
however there is no warranty
written or implied.  So 
basically, if there is a bug in
it... fix it yourself! :-)

-Branden Hall
 bhall@randinteractive.com


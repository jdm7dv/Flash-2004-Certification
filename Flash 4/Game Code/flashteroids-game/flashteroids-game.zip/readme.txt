By using this .fla file, you agree that the source code and resulting files are to be used for non-commercial purposes only. You cannot charge for the use of this game, nor include it on any media (CD, DVD etc) without the authors permission. To get permission please contact flash@atomicmedia.net


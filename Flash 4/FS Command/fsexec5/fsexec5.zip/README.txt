FLASHLITE.NET SAMPLE SOURCE FILE

http://www.flashlite.net
flash@flashlite.net

----------------------------------------------------------------

This package of FLAs demonstrate opening external files without 
the use of a BAT file.  This procedure was originally brought to 
our attention by Gabriel Suchowolski (gsucho@arroba.es).  You 
may use the source FLAs for your own projects, but please do not
distribute them without first securing permission from 
Flashlite.net

----------------------------------------------------------------

What's In the Package:

fsexec4a.fla - opens a URL
fsexec4b.fla - opens a local HTML file (mydoc.html)
fsexec4c.fla - opens a local text file (mydoc.txt)
fsexec4d.fla - opens a local WAV file (ding.wav)

----------------------------------------------------------------

Remember to export the movies to test their functionality, as
the FS Command "Exec" does not work in the editing environment,
or in "Test Movie".


#!/usr/local/bin/perl

# required hidden fields:
# recipient - your e-mail address
# subject - subject of the message
# redirect - url to load when form is submitted

# use name="email" for e-mail address field

# Check path to your e-mail program and change path if it is different
# from below
$mailprog = '/usr/lib/sendmail';


$date=`date +%D`;
$date=~s/\n$//;

$formdata=<STDIN>;
$formdata=~s/\s+$//;

foreach (split(/&/, $formdata))
{
($name, $value)=split(/=/, $_);
$name=~s/\+/ /g;
$name=~s/%([0-9|A-F]{2})/pack(C,hex($1))/eg;
$value=~s/\+/ /g;
$value=~s/%([0-9|A-F]{2})/pack(C,hex($1))/eg;

# if ($value eq "")
	#{
	#&exit($name);
	#}

if ($name ne "recipient" && $name ne "subject" && $name ne "redirect")
	{
	push (@print, $name)
	}
	

$data{$name}=$value;
}
if ($data{'email'} ne "" && $data{'email'} !~ /^[\w\.-]+@[\w\.-]+$/)
	{
	print "Content-type: text/html\n\n";
	print "<html><head></head><body bgcolor=\"ffffff\">";
	print "Please enter correct e-mail address.";
	exit;
	}
 

open(MAIL, "|$mailprog -t") || die "Can't open $mailprog!\n";
print MAIL "To: $data{'recipient'}\n";
print MAIL "From: $data{'email'}\n";

 #print MAIL "Cc: $data{'email'}\n";

if ($data{'subject'}) 
{
   print MAIL "Subject: $data{'subject'}\n\n";
}

else {
   print MAIL "Subject: WWW Form Submission\n\n";
}

foreach (@print)
	{
	print MAIL "$_: $data{$_}\n";
	}


close MAIL;

#print "Location:  $data{'redirect'}\n\n"; 

sub exit
{
local ($name)=@_;
print "Content-type: text/html\n\n";
print "<html><head></head><body bgcolor=\"ffffff\">";
print "Your must fill in <b>$name</b> to process this form.";
print " Please return back and do it. Thank you.";
print "</body></html>";
exit;
}

	


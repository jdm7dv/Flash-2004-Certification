Please Note:

The Film Grain Effect included with this file is not optimized for 
full screen use. To use the effect on a large area, first edit the
symbols in the Library to reduce detail. This will prevent performance
slow-downs on older systems.
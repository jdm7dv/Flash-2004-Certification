FREE FLASH FILES
                from
                    Digital Vision Multimedia

_________________________________
1. What are the free Flash files?

     They are what we call "cookies". Small and sweet :-)


_______________________________________________
2. Why are we doing them? And for what purpose?

     These files are not tutorials, they were never meant to be. When we have
     time to spare, we experiment with Flash in order to better understand it
     and to create something nice/interesting.

     We thought that others could benefit from them too, so we have opened a 
     new section within our site and offered these files for free download to 
     play with and hopefully *learn* a bit.


______________
3. Who are we?

     Digital Vision Multimedia is a design studio specialized in web site concept,
     design and development, 3D artwork and multimedia presentations, and we have
     a 4+ years of experience in the field.

     You may find more details at http://www.media-division.com


_________________
4. Terms of usage

     When you open a file in Flash, you agree that you may use all these files for
     personal purposes only. 

     This means that you are free to look at the source code and learn from it, and 
     make other works based on the original file. You may also include the compiled
     .swf file in a personal web site (you are encouraged to credit us).

     You may not redistribute the source file in any form (like offering it for 
     download) and you may not use it for commercial purposes (like including it in 
     your client's site) without our permission. Write us at dvinfo@media-division.com 
     for details.

     As much as we hate boring disclaimers, here we go (short version):
     ALL SOFTWARE IS PROVIDED "AS IS." DIGITAL VISION EXPRESSLY DISCLAIMS ALL WARRANTIES,
     EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
     MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. UNDER NO CIRCUMSTANCES, SHALL 
     DIGITAL VISION BE LIABLE FOR ANY INCIDENTAL, SPECIAL, INDIRECT OR CONSEQUENTIAL 
     DAMAGES. THE ENTIRE RISK ARISING OUT OF USE OR PERFORMANCE OF THE SOFTWARE REMAINS 
     WITH YOU. 

     This means: You got it for free, so you gon't get any warranty of any kind.
     If it breaks, bad luck.

Visit us at http://www.media-division.com
E-Mail us at dvinfo@media-division.com
